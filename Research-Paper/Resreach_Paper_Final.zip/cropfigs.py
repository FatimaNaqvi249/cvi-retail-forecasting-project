import sys
from pathlib import Path

import numpy as np
from PIL import Image

FIG = Path(sys.argv[1] if len(sys.argv) > 1 else "figures")


def ink(img):
    return np.asarray(img.convert("L"), dtype=np.int16) < 247


def snap(dens, frac, width, window=0.02):
    """Nearest lowest-ink column to `frac` of the width: the true panel boundary."""
    lo, hi = int(width * (frac - window)), int(width * (frac + window))
    return lo + int(np.argmin(dens[lo:hi]))


def trim(im, pad=6):
    r, c = np.where(ink(im))
    return im.crop((max(0, c.min() - pad), max(0, r.min() - pad),
                    min(im.width, c.max() + pad + 1), min(im.height, r.max() + pad + 1)))


def split(name, fracs, out_names):
    im = Image.open(FIG / name).convert("RGB")
    dens = ink(im).sum(axis=0)
    bounds = [0] + [snap(dens, f, im.width) for f in fracs] + [im.width]
    print(f"{name} {im.size} -> cut at {bounds[1:-1]}")
    for (a, b), out in zip(zip(bounds, bounds[1:]), out_names):
        panel = trim(im.crop((a, 0, b, im.height)))
        panel.save(FIG / out)
        w, h = panel.size
        print(f"  {out:22s} {w}x{h}  aspect {w/h:.2f}  "
              f"height at 3.45in = {3.45*h/w:.2f}in")


# left: MAE bar chart | right: improvement heat-map (with its colour bar)
split("fig_configs.png", [0.4653], ["fig_configs_a.png", "fig_configs_b.png"])
# three cross-retailer panels: CVI-enhanced | raw activity | sales analogue
split("fig_cross.png", [0.342, 0.666],
      ["fig_cross_a.png", "fig_cross_b.png", "fig_cross_c.png"])
